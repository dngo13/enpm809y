//
// Created by zeid on 9/10/20.
//
#include <iostream>

#ifndef LECTURE02_GOOGLE_H
#define LECTURE02_GOOGLE_H

void print(std::string s){
    std::cout << s << std::endl;
}

#endif //LECTURE02_GOOGLE_H
