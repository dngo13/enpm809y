//
// Created by zeid on 9/10/20.
//
#include <iostream>

#ifndef LECTURE02_APPLE_H
#define LECTURE02_APPLE_H

void print(std::string s){
    std::cout << s << std::endl;
}
#endif //LECTURE02_APPLE_H
