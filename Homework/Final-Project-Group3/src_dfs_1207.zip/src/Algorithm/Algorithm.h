/**
 * Algorithm.h
 */
#ifndef FINAL_PROJECT_GROUP3_ALGORITHM_H
#define FINAL_PROJECT_GROUP3_ALGORITHM_H
#include <iostream>
#include <memory>
#include <stack>
#include "../LandBasedRobot/LandBasedRobot.h"
#include "../Maze/Maze.h"
#include <array>


//DFS Algorithm from S to G
//Down right up left
namespace fp {
    class Algorithm {
    public:
        /**
         * Position structure for the x and y coordinate of the robot
         */
        struct Position{
            int x{0};
            int y{0};
        }position, current_pos;
        /**
         * A method to print out text to the maze simulator
         * @param text
         */
        static void log(const std::string& text);
        /**
         * Function to update the direction of the robot
         * @param current_direction char direction of N/S/E/W
         * @param turn char to specify if the robot is turning left or right
         */
        void UpdateDirection(char& current_direction, char turn);
        /**
         * Function to update the position of the robot
         * @param current_direction char direction of N/S/E/W
         * @param move
         * @param curr_pos
         */
        void UpdatePosition(char current_direction, char move, Position& curr_pos);

        /**
         * Initializes the maze with default settings
         * @param position
         * @param direction
         */
        static void InitializeMaze(fp::Algorithm::Position &position, char& direction);
        /**
         * Starts the setup for the maze and algorithm
         */
        void Solve();

        void DFS(bool start, char& current_direction, const std::shared_ptr<fp::LandBasedRobot> &robot);
        bool ResetPressed();
        void reset();
        /**
         * Function to set the center and perimeter of the maze
         */
        void CallSetMaze();
        /**
        * CheckWall is a method to check if there is a wall in the front, left, and
        * right side of the robot
        * @param current_position current position of the robot
        * @param direction direction that the robot is facing
        * @return
        */
        void CheckWall(Position &position, char &current_direction);
        /**
         * SetWall is a method to set a wall after the robot has found a wall
         * @param position
         */
        void SetWall(Position &position, char direction, bool hasWall);
        void FindNextNode(std::array<int, 2> curr_node, char current_direction, bool path_blocked_);

        std::stack<std::array<int, 2>> stack_;
        std::shared_ptr<fp::LandBasedRobot> robot_;

        std::array<std::array <bool, 16>, 16> visited_node_;
        std::array<int, 2> curr_node;
        std::array<int, 2> next_node;
        std::array<int, 2> parent_node;
        std::array<int, 2> goal_1, goal_2, goal_3, goal_4;

        bool is_visited(std::array<int, 2> node);
        bool path_found_{false};
        bool path_blocked_;
        bool CheckPath(bool path_blocked_, std::array<int, 2> next_node, char direction);
        //Constructor for Algorithm
        Algorithm(): robot_{nullptr},stack_{}, curr_node{}, next_node{}, visited_node_{} {}
        //goal_1{}, goal_2{}, goal_3{}, goal_4{}
        //Destructor
        ~Algorithm() = default;
    protected:
        Maze maze;
        char direction{'n'};

        void ClearStack();

        void MoveLeft();

        void MoveRight();


    }; //-class Algorithm


} //--namespace fp

#endif //FINAL_PROJECT_GROUP3_ALGORITHM_H
