/**
 * Algorithm.cpp
 */

#include "Algorithm.h"
#include <iostream>
#include <string>
#include "../API/api.h"
#include "../Maze/Maze.h"
#include "../Maze/Maze.cpp"
#include "../LandBasedRobot/LandBasedRobot.h"

void fp::Algorithm::log(const std::string& text) {
    std::cerr << text << std::endl;
}

void fp::Algorithm::ClearStack() {
    while(!stack_.empty()){
        stack_.pop();
    }
}

void fp::Algorithm::CallSetMaze() {
    maze.SetCenter();
    maze.SetPerimeterWalls();

}

void fp::Algorithm::Solve() {
    if (Maze::MAZE_HEIGHT != API::mazeHeight()) {
        if (Maze::MAZE_WIDTH != API::mazeWidth())
            std::cout << "Error, the maze dimensions must match. " << std::endl;
    }
    API::clearAllColor();
    log("~--~Starting~~--");

    InitializeMaze(position, direction);
    CallSetMaze();
    //  while (true) {
    //  }
    //if (Maze::Unsolvable == true) {
    //    std::cerr << "The maze cannot be solved. " << std::endl;
    //    break;
    //  }


//    while (!fp::API::wallFront()) {
//        fp::API::moveForward();
//        UpdatePosition(direction, 'f', current_pos);
//        fp::Algorithm::CheckWall(current_pos, direction);
//    }
bool start = true;
while (true) {
    DFS(start, robot_);
    if (ResetPressed()) {
        reset();
    }
    break;
}

}
void fp::Algorithm::UpdateDirection(char &current_direction, const char turn) {
    log("Turning " + std::string(1,turn));
    if (current_direction=='n') {
        if (turn== 'l')
            current_direction = 'w';
        else
            current_direction = 'e';
    }
    else if (current_direction=='e') {
        if (turn== 'l')
            current_direction = 'n';
        else
            current_direction = 's';
    }
    else if (current_direction=='s') {
        if (turn== 'l')
            current_direction = 'e';
        else
            current_direction = 'w';
    }
    else if (current_direction=='w') {
        if (turn== 'l')
            current_direction = 's';
        else
            current_direction = 'n';
    }
    log(std::string(1,current_direction));
}

void fp::Algorithm::UpdatePosition(const char current_direction, const char move, Position &curr_pos) {
    if (current_direction == 'n') {
        if (move == 'f')
            curr_pos.y++;
        else
            curr_pos.y--;
    }
    else if (current_direction == 'e') {
        if (move == 'f')
            curr_pos.x++;
        else
            curr_pos.x--;
    }
    else if (current_direction == 's') {
        if (move == 'f')
            curr_pos.y--;
        else
            curr_pos.y++;
    }
    else if (current_direction == 'w') {
        if (move == 'f')
            curr_pos.x--;
        else
            curr_pos.x++;
    }
}

void fp::Algorithm::InitializeMaze(Position &position, char& direction) {
    position.x = 0;
    position.y = 0;
    direction = 'n';
}

bool fp::Algorithm::ResetPressed() {
    return API::wasReset();
}

void fp::Algorithm::reset() {
    API::ackReset();
    position.x = 0;
    position.y = 0;
    direction = 'n';
}

void fp::Algorithm::MoveLeft() {
    fp::API::turnLeft();
    fp::API::moveForward();
}
void fp::Algorithm::MoveRight(){
    fp::API::turnRight();
    fp::API::moveForward();
}

bool fp::Algorithm::CheckWall(Position &current_pos, char direction) {
    log("Checking walls. ");
    bool hasWall;
    //Check South
    if (direction == 's') {
        log("south");
        if (fp::API::wallLeft()) {
            SetWall(current_pos, 'e', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("South - wall left");

            //hasWall = true;
        }
        if (fp::API::wallFront()) {
            SetWall(current_pos, 's', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("South - wall front");
            hasWall = true;
            return hasWall;
        } else if (!fp::API::wallFront()) {
            hasWall = false;
            log("South - no wall front ");
        }
        if (fp::API::wallRight()) {
            SetWall(current_pos, 'w', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("South - wall right");

            //hasWall = true;
        }
    }
    //Check East
    if (direction == 'e') {
        log("east");
        if (fp::API::wallLeft()) {
            // fp::API::setWall(current_pos.x, current_pos.y, 'n');
            hasWall = true;
            SetWall(current_pos, 'n', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("East - wall left");
            //hasWall = true;

        } else
            hasWall = false;
        if (fp::API::wallFront()) {
            //fp::API::setWall(current_pos.x, current_pos.y, 'e');
            SetWall(current_pos, 'e', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("East - wall front");
            hasWall = true;

            return hasWall;
        }
        if (fp::API::wallRight()) {
            //fp::API::setWall(current_pos.x, current_pos.y, 's');
            hasWall = true;
            SetWall(current_pos, 's', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("East - wall right");

        }
    }
    //Check North
    if (direction == 'n') {
        log("north");
        if (fp::API::wallLeft()) {
            //fp::API::setWall(current_pos.x, current_pos.y, 'w');
            SetWall(current_pos, 'w', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("North - wall left");
            hasWall = true;

        } else
            hasWall = false;
        if (fp::API::wallFront()) {
            //fp::API::setWall(current_pos.x, current_pos.y, 'n');
            SetWall(current_pos, 'n', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("North - wall front");
            hasWall = true;

            return hasWall;
        } else
            hasWall = false;
        if (fp::API::wallRight()) {
           // fp::API::setWall(current_pos.x, current_pos.y, 'e');
            SetWall(current_pos, 'e', hasWall);
            log(std::to_string(current_pos.x));
            log(std::to_string(current_pos.y));
            log("North - wall right");
            hasWall = true;
        } else
            hasWall = false;
    }
    //Check West
    if (direction == 'w') {
        log("west");
        if (fp::API::wallLeft()) {
            hasWall = true;
            SetWall(current_pos, 's', hasWall);
        }
        if (fp::API::wallFront()) {
            hasWall = true;
            SetWall(current_pos, 'w', hasWall);
            return hasWall;
        }
        if (fp::API::wallRight()) {
            hasWall = true;
            SetWall(current_pos, 'n', hasWall);
        }
    }

}



void fp::Algorithm::SetWall(Position &current_pos, char direction, bool hasWall) {
    fp::Algorithm::log("Setting walls. ");
    if (!hasWall)
        fp::API::setWall(current_pos.x, current_pos.y, direction);
}

void fp::Algorithm::DFS(bool start, const std::shared_ptr<fp::LandBasedRobot> &robot) {
    robot_ = robot;
    std::array<int, 2> curr_node = {current_pos.x, current_pos.y};
    std::array<int, 2> next_node = {};
    std::array<int, 2> parent_node = {};
    parent_node = curr_node;
    log("Pushing stack ");
    stack_.push(curr_node);
    //visited_node[current_pos.x][current_pos.y] = true;
   // log("Set to south");
   if (start) {
       direction = 's';
   }
    char current_direction = direction;
    bool hasWall;
    log("Checking south");
    std::array<int, 2> position_array = {current_pos.x, current_pos.y};
    while (position_array != goal_1 || position_array != goal_2 || position_array != goal_3 ||
           position_array != goal_4) {
        CheckWall(current_pos, current_direction);
        log(std::to_string(curr_node[0]));
        log(std::to_string(curr_node[1]));
        log("---");
        log(std::to_string(current_pos.x));
        log(std::to_string(current_pos.y));
        log("Check if direction has wall");
        //fp::API::wallFront()
        while (true) {
            /*log("Move left");
            fp::API::turnLeft();
            */
            while (fp::API::wallFront()){
                fp::API::turnLeft();
                UpdateDirection(current_direction, 'l');
            }
            while (!fp::API::wallFront()) {
                fp::API::moveForward();
                UpdatePosition(current_direction, 'f', current_pos);
                log(std::to_string(current_pos.x));
                log(std::to_string(current_pos.y));
                CheckWall(current_pos, current_direction);
                next_node = curr_node;
                if (!fp::API::wallFront()) {
                    log("Move forward");
                    fp::API::moveForward();
                    log("Update position");
                    UpdatePosition(current_direction, 'f', current_pos);
                    CheckWall(current_pos, current_direction);
                    log(std::to_string(current_pos.x));
                    log(std::to_string(15 + current_pos.y));
                    parent_node = curr_node;
                }

            }
       /*    if (fp::API::wallLeft()) {
                fp::API::turnRight();
                UpdateDirection(current_direction, 'r');
            }
            if (fp::API::wallFront() && fp::API::wallRight()) {
                fp::API::turnLeft();
                UpdateDirection(current_direction, 'l');
            }*/
        }
        position_array = {current_pos.x, current_pos.y};
        /**
         * Arrays to define the possible direction of the nodes , north, south, east, west
         */
        //std::array<int, 2> north_node = {curr_node[0] - 1, curr_node[1]};
        //std::array<int, 2> east_node = {curr_node[0], curr_node[1] + 1};
        //std::array<int, 2> south_node = {curr_node[0] + 1, curr_node[1]};
        //std::array<int, 2> west_node = {curr_node[0], curr_node[1] - 1};

    }
}
