/**
 * Algorithm.h
 */
#ifndef FINAL_PROJECT_GROUP3_ALGORITHM_H
#define FINAL_PROJECT_GROUP3_ALGORITHM_H
#include <iostream>
#include <memory>
#include <stack>
#include "../LandBasedRobot/LandBasedRobot.h"
#include "../Maze/Maze.h"
#include <array>


//DFS Algorithm from S to G
//Down right up left
namespace fp {
    class Algorithm {
    public:
        /**
         * Position structure for the x and y coordinate of the robot
         */
        struct Position{
            int x{0};
            int y{0};
        }position, current_pos;
        /**
         * A method to print out text to the maze simulator
         * @param text
         */
        static void log(const std::string& text);
        /**
         * Function to update the direction of the robot
         * @param current_direction char direction of N/S/E/W
         * @param turn char to specify if the robot is turning left or right
         */
        void UpdateDirection(char& current_direction, char turn);
        /**
         * Function to update the position of the robot
         * @param current_direction char direction of N/S/E/W
         * @param move
         * @param curr_pos
         */
        void UpdatePosition(char current_direction, char move, Position& curr_pos);

        /**
         * Initializes the maze with default settings
         * @param position
         * @param direction
         */
        static void InitializeMaze(fp::Algorithm::Position &position, char& direction);
        /**
         * Starts the setup for the maze and algorithm
         */
        void Solve();

        void DFS(bool start, const std::shared_ptr<fp::LandBasedRobot> &robot);
        bool ResetPressed();
        void reset();
        /**
         * Function to set the center and perimeter of the maze
         */
        void CallSetMaze();
        /**
        * CheckWall is a method to check if there is a wall in the front, left, and
        * right side of the robot
        * @param current_position current position of the robot
        * @param direction direction that the robot is facing
        * @return
        */
        bool CheckWall(Position &position, char direction);
        /**
         * SetWall is a method to set a wall after the robot has found a wall
         * @param position
         */
        void SetWall(Position &position, char direction, bool hasWall);

        std::stack<std::array<int, 2>> stack_;
        std::shared_ptr<fp::LandBasedRobot> robot_;
//
//        int row_num = 0;
//        int col_num = 0;
//        std::array<std::array<bool> visited_node[row_num][col_num]>;
        //bool visited_node[row_num][col_num] = {false};

        std::array<int, 2> goal_1 = {7, 7};
        std::array<int, 2> goal_2 = {7, 8};
        std::array<int, 2> goal_3 = {8, 7};
        std::array<int, 2> goal_4 = {8, 8};
        bool path_found_{false};
        bool path_blocked_;

        //bool visited_node[row_num][col_num]{false};
        // visited_node{}
        //Constructor for Algorithm
        Algorithm(): robot_{nullptr},stack_{}   {
        }

        //Destructor
        ~Algorithm() = default;
    protected:
        Maze maze;
        char direction{'N'};

        void ClearStack();

        void MoveLeft();

        void MoveRight();
    }; //-class Algorithm


} //--namespace fp

#endif //FINAL_PROJECT_GROUP3_ALGORITHM_H
