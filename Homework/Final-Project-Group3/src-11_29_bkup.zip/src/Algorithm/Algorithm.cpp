/**
 * Algorithm.cpp
 */

#include "Algorithm.h"
#include <iostream>
#include <string>
#include "../API/api.h"
#include "../Maze/Maze.h"
#include "../LandBasedRobot/LandBasedRobot.h"

void fp::Algorithm::log(const std::string& text) {
    std::cerr << text << std::endl;

}

void fp::Algorithm::ClearStack() {
    while(!stack_.empty()){
        stack_.pop();
    }
}

/**
 * Initialize center of the maze by setting the color and text of the 4 center tiles
 */
void fp::Algorithm::SetCenter() {
    fp::API::setColor(0, 0,  'G');
    fp::API::setText(0, 0, "S");
    fp::API::setText(7, 7, "G");
    fp::API::setColor(7, 7,  'B');
    fp::API::setText(7, 8, "G");
    fp::API::setColor(7, 8,  'B');
    fp::API::setText(8, 7, "G");
    fp::API::setColor(8, 7,  'B');
    fp::API::setText(8, 8, "G");
    fp::API::setColor(8, 8,  'B');
}

void fp::Algorithm::SetPerimeterWalls() {
    for (int x=0; x < Maze::MAZE_WIDTH; x++){
        for(int y=0; y < Maze::MAZE_HEIGHT; y++){
            if (x == 0) {
                fp::API::setWall(x, 15-x, 'W');
            }
            if (y == 0) {
                fp::API::setWall(x, 15-y, 'S');
            }
            if (x == 15){
                fp::API::setWall(x, 15-x, 'E');
            }
            if (y == (Maze::MAZE_HEIGHT - 1)) {
                fp::API::setWall(x, 15-y, 'N');
            }
            log("why no set wall");
//            fp::API::setWall(0+y, 15-x, 'E');
//            fp::API::setWall(0+y, 15-x, 'E');
//            fp::API::setWall(0+y, x, 'E');
//            fp::API::setWall(3, 15, 'S');
            log("x");
            log(std::to_string(x));
            log("y");
            log(std::to_string(y));
            //std::cout << "setting fake walls " << std::endl;
        }
    }

}

void fp::Algorithm::Solve() {
    if (Maze::MAZE_HEIGHT != API::mazeHeight()) {
        if (Maze::MAZE_WIDTH != API::mazeWidth())
            std::cout << "Error, the maze dimensions must match. " << std::endl;
    }
    log("~--~Starting~~--");

    InitializeMaze(position, direction);
    SetPerimeterWalls();

    //  while (true) {
    API::clearAllColor();

    API::setColor(0, 0, 'G');
    SetCenter();




    //  }
        //if (Maze::Unsolvable == true) {
        //    std::cerr << "The maze cannot be solved. " << std::endl;
        //    break;
        //  }
        //std::array<int, 2> &current_position, char &direction
//            Position current_pos;
//            CheckWall(curr_pos,  direction);
//            curr_pos.x = 0;
//            curr_pos.y = 0;
//            direction = 'N';
        current_pos = {};
        log("Can i check wall?");
        for(int x =0; x<15; x++){
            for(int y=0; y<15; y++) {
                current_pos.y = y;
                current_pos.x = x;
                fp::API::setWall(x, y, direction);
                //fp::Maze::CheckWall( fp::Algorithm::Position current_pos, &direction);
                //fp::API::setWall(y, 15-x, 'W');
                //fp::API::setWall(y, 15-x, 'W');
                //fp::API::setWall(y, x, 'W');
                //fp::API::setWall(3, 0, 'W');
            }
        }


        while(!fp::API::wallFront()) {
            fp::API::moveForward();
            UpdatePosition(direction, 'f', position);
        }
        //fp::Maze::CheckWall(current_pos,  direction);
        //current_pos.x = 0;
        //current_pos.y = 0;
        //direction = 'N';
            if (!fp::API::wallLeft()) {
                fp::API::turnLeft();
                UpdateDirection(direction, 'l');
            }
            while (fp::API::wallFront()) {
                fp::API::turnRight();
                UpdateDirection(direction, 'r');
            }
            fp::API::moveForward();
            UpdatePosition(direction, 'f', position);

    if (ResetPressed()) {
        reset();

//        log(std::to_string(position.x));
//        log(std::to_string(position.y));
//        log("--------");


    }
}

void fp::Algorithm::UpdateDirection(char &current_direction, const char turn) {
    log("Turning " + std::string(1,turn));
    if (current_direction=='N') {
        if (turn== 'l')
            current_direction = 'W';
        else
            current_direction = 'E';
    }
    else if (current_direction=='E') {
        if (turn== 'l')
            current_direction = 'N';
        else
            current_direction = 'S';
    }
    else if (current_direction=='S') {
        if (turn== 'l')
            current_direction = 'E';
        else
            current_direction = 'W';
    }
    else if (current_direction=='W') {
        if (turn== 'l')
            current_direction = 'S';
        else
            current_direction = 'N';
    }
    log(std::string(1,current_direction));
}

void fp::Algorithm::UpdatePosition(const char current_direction, const char move, fp::Algorithm::Position &position) {
    if (current_direction == 'N') {
        if (move == 'f')
            position.y++;
        else
            position.y--;
    }
    else if (current_direction == 'E') {
        if (move == 'f')
            position.x++;
        else
            position.x--;
    }
    else if (current_direction == 'S') {
        if (move == 'f')
            position.y--;
        else
            position.y++;
    }
    else if (current_direction == 'W') {
        if (move == 'f')
            position.x--;
        else
            position.x++;
    }
}

void fp::Algorithm::InitializeMaze(fp::Algorithm::Position &position, char& direction) {
    position.x = 0;
    position.y = 0;
    direction = 'N';

}

bool fp::Algorithm::ResetPressed() {
    return API::wasReset();
}

void fp::Algorithm::reset() {
    API::ackReset();
    position.x = 0;
    position.y = 0;
    direction = 'N';
}

void fp::Algorithm::DFS(const std::shared_ptr<fp::LandBasedRobot> &robot) {
    robot_ = robot;
    char current_direction{robot->GetDirection()};
}

void fp::Algorithm::MoveLeft() {
    fp::API::turnLeft();
    fp::API::moveForward();
}
void fp::Algorithm::MoveRight(){
    fp::API::turnRight();
    fp::API::moveForward();
}
