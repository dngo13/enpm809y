* Start with a `DISCRETE` algorithm. Once that's working, implement a `CONTINUOUS` one.
* Don't include the STL
