# units

This directory contains unit classes. These classes allow us, the simulation
developers, to not have to think about conversions between units. Instead, we
only have to "deal with" the abstract metric that we want (i.e., `Distance`,
`Duration`, `Speed`, etc.).
