#include "DoNothing.h"

namespace doNothing {

void DoNothing::solve(
        int mazeWidth, int mazeHeight, bool isOfficialMaze,
        char initialDirection, sim::MouseInterface* mouse) {
}

} // namespace doNothing
