# pragma once

namespace mackAlgoTwo {

typedef unsigned char byte;
typedef unsigned int twobyte;

} // namespace mackAlgoTwo
