# doNothing

This directory contains a Micromouse that, as its name implies, does nothing.
This algorithm is useful for when you're writing a maze-generation algorithm
and don't want any specific functionality from the mouse algorithm.
