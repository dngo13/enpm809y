# manual

This algorithm is more of a hack than anything else. It allows a user to
control the Micromouse with the arrow keys. To try it out, simply change the
value of `mouse-algorithm` in `res/parameters.xml` to be `MANUAL`. Then, run
the simulation and use the arrow keys to control the mouse.

Maybe we'll turn this into a game or something. For now it serves little to no
purpose, other than being entertaining.
