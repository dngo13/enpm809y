# forward

This mouse algorithm tries to move forward continually. And that's really all
that can be said about it...
