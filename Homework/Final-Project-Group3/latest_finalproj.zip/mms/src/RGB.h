#pragma once

namespace mms {

struct RGB {
    unsigned char r;
    unsigned char g;
    unsigned char b;
};

} 
