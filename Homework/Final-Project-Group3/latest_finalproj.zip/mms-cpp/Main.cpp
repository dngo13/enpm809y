#include <iostream>
#include <string>

#include "API.h"

void log(const std::string& text) {
    std::cerr << text << std::endl;
}

void UpdateDirection(char current_direction, const char turn){
    log( "Turning " + std::string(1,turn));
    if (current_direction=='N') {
        if (turn== 'l')
            current_direction = 'W';
        else
            current_direction = 'E';
    }
    else if (current_direction=='E') {
        if (turn== 'l')
            current_direction = 'N';
        else
            current_direction = 'S';
    }
    else if (current_direction=='S') {
        if (turn== 'l')
            current_direction = 'W';
        else
            current_direction = 'E';
    }
    else if (current_direction=='W') {
        if (turn== 'l')
            current_direction = 'S';
        else
            current_direction = 'N';
    }
    log( "Turning " + std::string(1,current_direction));
}

int main(int argc, char* argv[]){
    char direction{'N'};
    std::cout<< "Main started" << std::endl;
    log("Starting...");
    API::setColor(0, 0, 'r');
    API::setText(0, 0, "S");
    API::setText(7, 7, "G");
    API::setText(7, 8, "G");
    API::setText(8, 7, "G");
    API::setText(8, 8, "G");

    while (true) {
        if (!API::wallLeft()) {
            API::turnLeft();
            UpdateDirection(direction, 'l');
        }
        while (API::wallFront()) {
            API::turnRight();
            UpdateDirection(direction, 'r');
        }
        API::moveForward();
    }
    return 0;
}