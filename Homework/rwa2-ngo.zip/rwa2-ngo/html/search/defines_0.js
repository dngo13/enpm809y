var searchData=
[
  ['cols',['COLS',['../main_8cpp.html#ab59ad2ee1a48b83c2eef1f019ed8cc48',1,'main.cpp']]]
];
